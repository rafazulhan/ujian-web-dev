<?php
// include database connection file
include("koneksi.php");
 // Get id from URL to delete that user
$id_pasen = $_GET['id_pasen'];
 // Delete user row from table based on given id
$query="DELETE FROM pasien WHERE id_pasen=$id_pasen";
$result = mysqli_query($connect,$query);
 // After delete redirect to Home, so that latest user list will be displayed.
header("Location:manage_pasien.php");
